from models import addition

def test_addition():
    addition(20,10)